export default {
    GET_ACCOUNTS: 'get_accounts',
    GET_ACCOUNTS_SUCCESS: 'get_accounts_success',
    GET_ROOMS: 'get_rooms',
    GET_ROOMS_SUCCESS: 'get_rooms_success',
    SHOW_NOTIFICATION: 'show_notification',
    CLEAR_NOTIFICATIONS: 'clear_notifications',
  };